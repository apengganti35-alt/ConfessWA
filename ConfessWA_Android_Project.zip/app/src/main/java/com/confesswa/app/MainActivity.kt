package com.confesswa.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF06131A)
private val Panel = Color(0xFF10232D)
private val Green = Color(0xFF18D889)
private val White = Color(0xFFEAF7F2)
private val Muted = Color(0xFF9CB5BC)

data class SendRecord(val number: String, val message: String, val status: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(
            primary = Green, background = Bg, surface = Panel,
            onPrimary = Bg, onBackground = White, onSurface = White
        )) { ConfessApp() } }
    }
}

@Composable
fun ConfessApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf("Beranda") }
    var number by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var sender by remember { mutableStateOf("") }
    var savedNumbers by remember { mutableStateOf(listOf<String>()) }
    var history by remember { mutableStateOf(listOf<SendRecord>()) }
    var status by remember { mutableStateOf("Demo lokal — sender API belum dihubungkan") }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Green) {
                listOf("Beranda", "Sender", "Riwayat", "Profil").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Icon(when (item) {
                                "Beranda" -> Icons.Default.Home
                                "Sender" -> Icons.Default.Smartphone
                                "Riwayat" -> Icons.Default.History
                                else -> Icons.Default.Person
                            }, contentDescription = item)
                        },
                        label = { Text(item) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Green, selectedTextColor = Green,
                            indicatorColor = Color(0xFF164A3B),
                            unselectedIconColor = Muted, unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)
                .background(Bg)
        ) {
            Spacer(Modifier.height(12.dp))
            Text("💚 Confess WA", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Green)
            Text("Confess jadi lebih mudah", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(18.dp))
            when (page) {
                "Beranda" -> {
                    CardBlock {
                        Text("Halo 👋", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Kirim pesan dengan cara sederhana. Gunakan secara bertanggung jawab.", color = Muted)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MenuTile("💌", "Kirim Confess", Modifier.weight(1f)) { page = "Kirim" }
                        MenuTile("📱", "Sender Nomor", Modifier.weight(1f)) { page = "Sender" }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MenuTile("📇", "Nomor Tersimpan", Modifier.weight(1f)) { page = "Nomor" }
                        MenuTile("🕘", "Riwayat", Modifier.weight(1f)) { page = "Riwayat" }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MenuTile("⚙️", "Pengaturan", Modifier.weight(1f)) { page = "Pengaturan" }
                        MenuTile("❔", "Bantuan", Modifier.weight(1f)) { page = "Bantuan" }
                    }
                    Spacer(Modifier.height(14.dp))
                    CardBlock {
                        Text("Status", fontWeight = FontWeight.Bold, color = Green)
                        Text(status, color = Muted)
                    }
                }
                "Kirim" -> {
                    Text("Kirim Confess", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    InputField("Nomor tujuan (contoh 628123456789)", number, { number = it }, KeyboardType.Phone)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = message, onValueChange = { if (it.length <= 1000) message = it },
                        label = { Text("Pesan confess") },
                        modifier = Modifier.fillMaxWidth().height(150.dp),
                        colors = fieldColors()
                    )
                    Spacer(Modifier.height(5.dp))
                    Text("${message.length}/1000", color = Muted, modifier = Modifier.align(Alignment.End))
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val clean = number.filter { it.isDigit() }
                            if (clean.length in 8..15 && message.isNotBlank()) {
                                history = listOf(SendRecord(clean, message, "Siap dibuka di WhatsApp")) + history
                                val uri = Uri.parse("https://wa.me/$clean?text=${Uri.encode(message)}")
                                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                                status = "WhatsApp dibuka; pesan belum dikirim otomatis."
                            } else status = "Periksa nomor dan isi pesan."
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)
                    ) { Text("Lanjutkan di WhatsApp", fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(8.dp))
                    Text("Aplikasi membuka WhatsApp untuk kamu meninjau dan mengirim pesan sendiri.", color = Muted)
                }
                "Sender" -> {
                    Text("Sender Nomor WA", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    InputField("Nomor WhatsApp milikmu", sender, { sender = it }, KeyboardType.Phone)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = { status = if (sender.filter { it.isDigit() }.length >= 8) "Nomor sender tersimpan di sesi aplikasi (demo)." else "Masukkan nomor yang valid." },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)) {
                        Text("Simpan Sender")
                    }
                    Spacer(Modifier.height(12.dp))
                    CardBlock {
                        Text("Catatan sender", fontWeight = FontWeight.Bold, color = Green)
                        Text("Nomor sender tidak bisa diaktifkan hanya dengan memasukkan nomor. Pengiriman otomatis memerlukan integrasi resmi WhatsApp Cloud API atau proses autentikasi yang didukung WhatsApp.", color = Muted)
                    }
                }
                "Nomor" -> {
                    Text("Nomor Tersimpan", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    InputField("Tambah nomor (format 628...)", number, { number = it }, KeyboardType.Phone)
                    Button(onClick = {
                        val clean = number.filter { it.isDigit() }
                        if (clean.length in 8..15) savedNumbers = (savedNumbers + clean).distinct()
                    }, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg)) { Text("+ Tambah Nomor") }
                    LazyColumn { items(savedNumbers) { n ->
                        CardBlock { Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(n, Modifier.weight(1f))
                            TextButton(onClick = { number = n; page = "Kirim" }) { Text("Pakai") }
                            TextButton(onClick = { savedNumbers = savedNumbers - n }) { Text("Hapus") }
                        } }
                    } }
                }
                "Riwayat" -> {
                    Text("Riwayat", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (history.isEmpty()) Text("Belum ada riwayat. Riwayat ini hanya tersimpan selama aplikasi berjalan.", color = Muted)
                    LazyColumn { items(history) { r ->
                        CardBlock {
                            Text(r.number, fontWeight = FontWeight.Bold, color = Green)
                            Text(r.message, color = White)
                            Text(r.status, color = Muted, fontSize = 12.sp)
                        }
                    } }
                }
                "Pengaturan" -> {
                    Text("Pengaturan", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    CardBlock {
                        Text("Tema: Gelap")
                        Text("Batas pesan: 1.000 karakter")
                        Text("Mode kirim: Buka WhatsApp untuk konfirmasi")
                        Text("Privasi: versi awal tidak mengirim data ke server.")
                    }
                }
                "Bantuan" -> {
                    Text("Bantuan", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    CardBlock {
                        Text("1. Pilih Kirim Confess.")
                        Text("2. Masukkan nomor tujuan dengan kode negara, misalnya 62.")
                        Text("3. Tulis pesan, lalu tekan Lanjutkan di WhatsApp.")
                        Text("4. Periksa pesan dan kirim sendiri dari WhatsApp.")
                        Spacer(Modifier.height(8.dp))
                        Text("Fitur sender otomatis belum aktif. Gunakan pesan secara sopan dan hanya kepada penerima yang bersedia.", color = Muted)
                    }
                }
                "Profil" -> {
                    Text("Profil", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    CardBlock {
                        Text("Confess WA", fontWeight = FontWeight.Bold, color = Green)
                        Text("Versi 1.0 — prototipe Android")
                        Text("Belum memakai login atau penyimpanan akun online.", color = Muted)
                    }
                }
            }
        }
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp), content = content)
    }
}

@Composable
fun MenuTile(emoji: String, title: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.Start) {
            Text(emoji, fontSize = 23.sp)
            Spacer(Modifier.height(7.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun InputField(label: String, value: String, onValueChange: (String) -> Unit, keyboard: KeyboardType) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        colors = fieldColors()
    )
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF34505B),
    focusedLabelColor = Green, unfocusedLabelColor = Muted,
    focusedTextColor = White, unfocusedTextColor = White,
    cursorColor = Green
)
