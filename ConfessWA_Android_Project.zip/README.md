# Confess WA — proyek Android sederhana

Proyek awal Android native (Kotlin + Jetpack Compose) untuk aplikasi Confess WA.

## Fitur saat ini
- Dashboard dengan menu Kirim Confess, Sender, Nomor Tersimpan, Riwayat, Pengaturan, Bantuan
- Form pesan confess dan nomor tujuan
- Simpan nomor lokal di memori selama aplikasi berjalan
- Riwayat demo lokal
- Tema gelap sederhana

## Batasan penting
Ini adalah **source project**, bukan APK yang sudah dikompilasi. Untuk menghasilkan APK, buka proyek di Android Studio lalu Build > Build APK(s).
Fungsi kirim WhatsApp nyata belum dihubungkan. Pengiriman resmi memerlukan konfigurasi WhatsApp Cloud API, token server yang aman, dan kepatuhan terhadap aturan opt-in/template WhatsApp. Jangan taruh token rahasia di aplikasi Android.
